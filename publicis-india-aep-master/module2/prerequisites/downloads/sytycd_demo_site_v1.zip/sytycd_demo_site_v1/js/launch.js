var launchTagUrl = "//assets.adobedtm.com/6d07e8369d1a/34f7c6752108/launch-96a417db7452-development.min.js";

dynamicallyLoadScript(launchTagUrl);

function dynamicallyLoadScript(url) {
    var script = document.createElement("script");
    script.src = url;
    script.async = true;
    document.head.appendChild(script);
}
