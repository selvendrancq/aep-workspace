function createUserPw() {
    $.ajax({
    url: "https://parseapi.back4app.com/users",
    dataType: "json",
    type: "post",
    headers: {
        "X-Parse-Application-Id":"7JDfgddYRLM0OHbb32TQupIQ3ujxUOjzxIGqnN73",
        "X-Parse-REST-API-Key":"3ji1hPEyXRhtO77R17N41oI2ssccdDrmjmbyHKp9",
        "X-Parse-Revocable-Session":"1"
    },
    data: {
        "password": localStorage.getItem('password'),
        "username": localStorage.getItem('email'),
        "email": localStorage.getItem('email')
        }
    })
};